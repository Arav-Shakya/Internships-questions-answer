from django.contrib import admin

from Answer.models import User

admin.site.register(User)
